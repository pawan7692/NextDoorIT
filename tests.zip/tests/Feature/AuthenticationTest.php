<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

use App\Models\User;

class AuthenticationTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function test_example()
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

    public function test_user_can_view_register_form()
    {
        $response = $this->get('/register');

        $response->assertStatus(200);
    }

    public function test_user_can_register_using_the_register_form() {

        $user = User::factory()->create()->toArray();

        $response = $this->post('/register', $user);

        $response->assertStatus(200);

        $this->assertDatabaseHas('users', $user);
    }

    public function test_user_can_view_login_form()
    {
        $response = $this->get('/login');

        $response->assertStatus(200);
    }

    public function test_user_can_login_using_the_login_form() {

        $user = User::factory()->create();
        
        $response = $this->post('/login', ['email' => $user->email, 'password' => 'password']);

        $response->assertStatus(200);

    }
}
